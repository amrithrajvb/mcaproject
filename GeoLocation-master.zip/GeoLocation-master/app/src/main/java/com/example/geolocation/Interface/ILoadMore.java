package com.example.geolocation.Interface;

/**
 * Created by Rizwan on 18-02-2018.
 */

public interface ILoadMore {

    void onLoadMore();
}
