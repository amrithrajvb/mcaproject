package com.example.geolocation.Connection;

/**
 * Created by surve on 27-Feb-18.
 */

public class APIList {

    public static final String BASE_URL = "https://www.adevole.com/clients/shoeb/";

    public static final String SEND_NOTIFICATION = "sendNotification.php?";
}
